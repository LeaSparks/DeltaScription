# The ground itself cracks as a fountain of darkness spews night from the earth...

Slay them? Spare them?, that's up to you to decide.



This mod adds cards for Act 1 Kaycee's Mod in the game Inscryption, inspired by the Darkners and Lightners from Toby Fox's Hit game deltarune.



PLEASE reach out to me on the Modding Discord if you encounter any bugs, visual or otherwise, this is an early access mod.



# Installation

If you're installing the mod manually:

- click the **Manual Download** button to download the package.

- Unzip the contents of the package to a new folder in your **plugins** directory.

- Make sure that you have installed all the dependencies required by this mod as well.

If you're using a mod manager it should just work.



# Release Notes

v1.7.0:

- This Mod currently features:

	- Flower Kingdom  |26/26 Cards| Complete!
	- Dark Sanctuary  |26/26 Cards| Complete!
	- TV World        |49/49 Cards| Testing Needed!
	- Cyber World     |42/42 Cards| Complete!
	- Card Kingdom    |30/30 Cards| Complete!
	- Hometown        |00/22 Cards| WIP
	- Weird Route     |02/?? Cards| WIP
	- Equipment       |06/60 Cards| WIP
	- Miscellaneous   |05/?? Cards| WIP
	- 20 new starter decks to try in this current state.



# Patch Notes

- Added new plugin for modifications to story
- ☼︎♏︎❍︎□︎❖︎♏︎♎︎ ☝︎❒︎♏︎♏︎■︎ 🏱︎♓︎❒︎♋︎⧫︎♏︎
- Rebalanced Cards

# Credits

- Lea - the main developer of the mod, put together the cards themselves and did the art assets for the project
- Toby Fox - for creating these lovely characters with his team

## Special Thanks

- Nevernamed - For some custom sigil implementation used on Flowery as well as the entire Nevernamed Sigils Pack

# Card List

WIP
https://github.com/LeaSparks/DeltaScription/wiki

